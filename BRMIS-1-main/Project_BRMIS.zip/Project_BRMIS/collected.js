    function goBack() {
      const confirmBack = confirm("Go back to the Add page?");
      if (confirmBack) {
        window.location.href = "add.html"; // Change to your actual Add page filename
      }
    }