let sidebar = document.querySelector(".sidebar");
let closeBtn = document.querySelector("#btn");
let searchBtn = document.querySelector(".bx-search");

// Select all navigation links and the home-section text container
const navLinks = document.querySelectorAll('.nav-list li a');
const homeSectionText = document.querySelector('.home-section .text');

closeBtn.addEventListener("click", () => {
    sidebar.classList.toggle("open");
    menuBtnChange();
})

searchBtn.addEventListener("click", () => {
    sidebar.classList.toggle("open");
    menuBtnChange();
})

function menuBtnChange() {
    if (sidebar.classList.contains("open")) {
        closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");
    } else {
        closeBtn.classList.replace("bx-menu-alt-right", "bx-menu");
    }
}

// Function to set the active tab
function setActiveTab(selectedTab) {
  // Remove the 'active' class from all tabs
  navLinks.forEach((link) => {
    link.parentElement.classList.remove('active');
  });

  // Add the 'active' class to the selected tab
  selectedTab.parentElement.classList.add('active');

  // Update the text in the home-section based on the selected tab
  const tabText = selectedTab.querySelector('.links_name').textContent;
  homeSectionText.textContent = tabText;
}

// Add click event listeners to all navigation links
navLinks.forEach((link) => {
  link.addEventListener('click', (event) => {
    event.preventDefault(); // Prevent default link behavior
    setActiveTab(link);
  });
});

// Set the default active tab (Dashboard) on page load
document.addEventListener('DOMContentLoaded', () => {
  const defaultTab = document.querySelector('.nav-list li a[data-section="dashboardSection"]'); // Adjust the selector if needed
  if (defaultTab) {
    setActiveTab(defaultTab);
  }
});

// Show the logout confirmation modal
function showLogoutModal() {
    const modal = document.getElementById('logoutModal');
    modal.style.display = 'flex'; // Show the modal
}

// Hide the logout confirmation modal
function hideLogoutModal() {
    const modal = document.getElementById('logoutModal');
    modal.style.display = 'none'; // Hide the modal
}

// Handle logout confirmation
function confirmLogout() {
    // Perform logout action (e.g., redirect to login page)
    window.location.href = 'login.html';
}

// Attach event listeners to modal buttons
document.getElementById('confirmLogout').addEventListener('click', confirmLogout);
document.getElementById('cancelLogout').addEventListener('click', hideLogoutModal);

// New code to handle section display based on navigation clicks
document.addEventListener('DOMContentLoaded', function () {
    const links = document.querySelectorAll('.nav-list a[data-section]');
    const sections = document.querySelectorAll('.content-section');

    function showSection(sectionId) {
        sections.forEach(section => {
            if (section.id === sectionId) {
                section.classList.add('active');
                section.style.display = 'block';
            } else {
                section.classList.remove('active');
                section.style.display = 'none';
            }
        });
        // Highlight active tab
        links.forEach(link => {
            link.parentElement.classList.toggle('active', link.getAttribute('data-section') === sectionId);
        });
    }

    // Header and Post Announcement Button logic
    const headerTitle = document.getElementById('dashboardHeaderTitle');
    const postBtn = document.getElementById('postAnnouncementBtn');
    const sectionTitles = {
        dashboardSection: 'BloodBank Record Management and Inventory System',
        inventorySection: 'Inventory Management',
        reservationSection: 'Reservation',
        newsSection: 'News & Updates',
        transcriptionSection: 'Transcription',
        summarySection: 'Summary Report',
        settingsSection: 'BloodBank Record Management and Inventory System',
    };
    function updateHeader(sectionId) {
        if (headerTitle) headerTitle.textContent = sectionTitles[sectionId] || '';
        if (postBtn) postBtn.style.display = (sectionId === 'dashboardSection') ? 'block' : 'none';
    }

    // Restore last active tab
    const savedSection = localStorage.getItem('activeSection') || 'dashboardSection';
    showSection(savedSection);
    updateHeader(savedSection);

    links.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const target = this.getAttribute('data-section');
            showSection(target);
            localStorage.setItem('activeSection', target);
            updateHeader(target);
        });
    });

    // System Settings Panel logic (if present)
    const openSystemSettings = document.getElementById('openSystemSettings');
    const closeSystemSettings = document.getElementById('closeSystemSettings');
    const systemSettingsPanel = document.getElementById('systemSettingsPanel');
    if (openSystemSettings && closeSystemSettings && systemSettingsPanel) {
        openSystemSettings.addEventListener('click', function () {
            systemSettingsPanel.style.display = 'block';
        });
        closeSystemSettings.addEventListener('click', function () {
            systemSettingsPanel.style.display = 'none';
        });
    }

    // Accordion logic for settings
    document.querySelectorAll('.accordion-header').forEach(header => {
        header.addEventListener('click', function () {
            this.classList.toggle('active');
            const panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + "px";
            }
        });
    });

    // Dropdown logic for Inventory and Reservation
    const inventoryBtn = document.getElementById('inventoryDropdownBtn');
    const reservationBtn = document.getElementById('reservationDropdownBtn');
    const inventoryDropdown = document.getElementById('inventoryDropdown');
    const reservationDropdown = document.getElementById('reservationDropdown');

    function closeAllDropdowns() {
        if (inventoryDropdown && inventoryBtn) {
            inventoryDropdown.style.maxHeight = '0';
            inventoryBtn.parentElement.classList.remove('open');
        }
        if (reservationDropdown && reservationBtn) {
            reservationDropdown.style.maxHeight = '0';
            reservationBtn.parentElement.classList.remove('open');
        }
    }

    function toggleDropdown(btn, dropdown) {
        if (!btn || !dropdown) return;
        const parentLi = btn.parentElement;
        const isOpen = parentLi.classList.contains('open');
        closeAllDropdowns();
        if (!isOpen) {
            parentLi.classList.add('open');
            dropdown.style.maxHeight = dropdown.scrollHeight + 'px';
        }
    }

    if (inventoryBtn && inventoryDropdown) {
        inventoryBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleDropdown(inventoryBtn, inventoryDropdown);
        });
    }
    if (reservationBtn && reservationDropdown) {
        reservationBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleDropdown(reservationBtn, reservationDropdown);
        });
    }

    // Close dropdowns when clicking outside sidebar
    document.addEventListener('click', function(e) {
        const sidebar = document.querySelector('.sidebar');
        if (!sidebar.contains(e.target)) {
            closeAllDropdowns();
        }
    });

    // Close dropdowns when sidebar is collapsed
    const closeBtn = document.querySelector("#btn");
    if (closeBtn) {
        closeBtn.addEventListener("click", () => {
            setTimeout(() => {
                if (!document.querySelector('.sidebar').classList.contains('open')) {
                    closeAllDropdowns();
                }
            }, 100);
        });
    }

    // Close dropdown when a sub-item is clicked
    document.querySelectorAll('.sidebar-dropdown a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.stopPropagation();
            closeAllDropdowns();
        });
    });
});

menuBtnChange();

searchBtn.addEventListener("click", () => {
    if (!sidebar.classList.contains("open")) {
        sidebar.classList.add("open");
        menuBtnChange();
    } else {
        document.querySelector(".sidebar input").focus();
    }
    });

document.addEventListener("DOMContentLoaded", function () {
    const postBtn = document.getElementById("postAnnouncementBtn");
    const popup = document.getElementById("announcementPopup");
    const popupBody = document.getElementById("announcementPopupBody");
    const closeBtn = document.getElementById("closeAnnouncementPopup");

    // 🔴 Post Announcement Logic
    postBtn.addEventListener("click", function () {
        popup.style.display = "flex";
        Promise.all([
            fetch("announcementbtn.html").then(res => res.text()),
            fetch("announcementbtn.css").then(res => res.text())
        ])
        .then(([html, css]) => {
            const bodyContent = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
            const styleTag = `<style>${css}</style>`;
            popupBody.innerHTML = styleTag + (bodyContent ? bodyContent[1] : html);
        })
        .catch(err => {
            popupBody.innerHTML = `<p style='color:red;'>Failed to load form. ${err.message}</p>`;
        });
    });

    closeBtn?.addEventListener("click", function () {
        popup.style.display = "none";
        popupBody.innerHTML = "";
    });

    popup?.addEventListener("click", function (e) {
        if (e.target === popup) {
            popup.style.display = "none";
            popupBody.innerHTML = "";
        }
    });

    // inventory View/Add Loader
    document.getElementById('loadView')?.addEventListener('click', (e) => {
        e.preventDefault();
        loadInventoryContent('view.html');
    });

    document.getElementById('loadAdd')?.addEventListener('click', (e) => {
        e.preventDefault();
        loadInventoryContent('add.html');
    });

function loadInventoryContent(file) {
    const container = document.getElementById('inventoryContainer');
    if (!container) return;

    // ✅ Clear previous content to prevent duplication
    container.innerHTML = "";

    fetch(file)
        .then(res => res.text())
        .then(html => {
            const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
            const headMatch = html.match(/<head[^>]*>([\s\S]*?)<\/head>/i);
            container.innerHTML = bodyMatch ? bodyMatch[1] : html;

            // ✅ Load dynamic CSS
            if (headMatch) {
                const tempHead = document.createElement('div');
                tempHead.innerHTML = headMatch[1];

                // Remove old styles
                document.querySelectorAll('link[data-dynamic-style]').forEach(link => link.remove());

                // Inject new styles
                const links = tempHead.querySelectorAll('link[rel="stylesheet"]');
                links.forEach(link => {
                    const newLink = document.createElement('link');
                    newLink.rel = 'stylesheet';
                    newLink.href = link.getAttribute('href');
                    newLink.setAttribute('data-dynamic-style', 'true');
                    document.head.appendChild(newLink);
                });
            }

            container.scrollIntoView({ behavior: 'smooth' });

            // ✅ Load JS if available
            const scriptMatch = html.match(/<script[^>]*src="([^"]+)"[^>]*><\/script>/gi);
            if (scriptMatch) {
                document.querySelectorAll('script[data-dynamic-script]').forEach(script => script.remove());

                scriptMatch.forEach(scriptTag => {
                    const srcMatch = scriptTag.match(/src="([^"]+)"/i);
                    if (srcMatch && srcMatch[1]) {
                        const newScript = document.createElement('script');
                        newScript.src = srcMatch[1];
                        newScript.setAttribute('data-dynamic-script', 'true');
                        document.body.appendChild(newScript);
                    }
                });
            }
        // ✅ Fallback: keep everything in the inventoryContainer
                if (file === 'add.html') {
                setTimeout(() => {
                    document.getElementById('btnCollected')?.addEventListener('click', e => {
                    e.preventDefault();
                    loadInventoryContent('collected.html');
                    });
                    document.getElementById('btnDonors')?.addEventListener('click', e => {
                    e.preventDefault();
                    loadInventoryContent('donor.html');
                    });
                    document.getElementById('btnDistributed')?.addEventListener('click', e => {
                    e.preventDefault();
                    loadInventoryContent('distributed.html');
                    });
                }, 300);
                }
        })
        .catch(err => {
            container.innerHTML = `<p style="color:red;">Failed to load ${file}: ${err.message}</p>`;
        });
}



    closeBtn.addEventListener("click", function () {
        popup.style.display = "none";
        popupBody.innerHTML = "";
    });

    popup.addEventListener("click", function (e) {
        if (e.target === popup) {
            popup.style.display = "none";
            popupBody.innerHTML = "";
        }
    });
});
