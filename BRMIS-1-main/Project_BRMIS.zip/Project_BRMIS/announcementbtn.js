document.querySelector('.close-btn').onclick = function() {
    window.location.href = 'dashboard.html';
};
document.querySelector('.cancel-btn').onclick = function() {
    window.location.href = 'dashboard.html';
};