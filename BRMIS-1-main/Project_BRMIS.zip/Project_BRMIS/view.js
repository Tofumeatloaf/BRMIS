function showTable(tableId) {
  const tables = document.querySelectorAll('.data-table');
  tables.forEach(t => t.classList.add('hidden'));
  document.getElementById(tableId).classList.remove('hidden');
}

function sortTable(header, colIndex) {
  const table = header.closest('table');
  const tbody = table.querySelector('tbody');
  const rows = Array.from(tbody.rows);

  const isAsc = header.classList.toggle('asc');
  header.classList.remove('desc');
  if (!isAsc) header.classList.add('desc');

  rows.sort((a, b) => {
    const valA = a.cells[colIndex].innerText;
    const valB = b.cells[colIndex].innerText;

    return isAsc
      ? valA.localeCompare(valB)
      : valB.localeCompare(valA);
  });

  tbody.innerHTML = '';
  rows.forEach(row => tbody.appendChild(row));
}

function filterTables() {
  const input = document.getElementById('searchInput').value.toLowerCase();
  document.querySelectorAll('table:not(.hidden) tbody tr').forEach(row => {
    const text = row.innerText.toLowerCase();
    row.style.display = text.includes(input) ? '' : 'none';
  });
}
