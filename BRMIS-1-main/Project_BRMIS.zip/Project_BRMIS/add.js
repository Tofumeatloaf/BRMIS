    document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById('inventoryContainer');
    if (!container) return;

    function loadSubPage(file) {
        fetch(file)
        .then(res => res.text())
        .then(html => {
            // Extract <body> content
            const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
            container.innerHTML = bodyMatch ? bodyMatch[1] : html;
            container.scrollIntoView({ behavior: 'smooth' });

            // Load external <script src="..."> manually
            const parser = new DOMParser();
            const parsedDoc = parser.parseFromString(html, 'text/html');
            const scriptElements = parsedDoc.querySelectorAll('script[src]');

            // Remove previously injected dynamic scripts
            document.querySelectorAll('script[data-dynamic-script]').forEach(el => el.remove());

            scriptElements.forEach(script => {
            const newScript = document.createElement('script');
            newScript.src = script.src;
            newScript.setAttribute('data-dynamic-script', 'true');
            document.body.appendChild(newScript);
            });

            // Bind buttons after load
            bindSubpageControls(file);
        })
        .catch(err => {
            container.innerHTML = `<p style="color:red;">Failed to load ${file}: ${err.message}</p>`;
        });
    }

    function bindSubpageControls(currentFile) {
        console.log("Binding controls for:", currentFile);
        if (currentFile === 'add.html') {
        document.getElementById('btnCollected')?.addEventListener('click', e => {
            e.preventDefault();
            loadSubPage('collected.html');
        });
        document.getElementById('btnDonors')?.addEventListener('click', e => {
            e.preventDefault();
            loadSubPage('donor.html');
        });
        document.getElementById('btnDistributed')?.addEventListener('click', e => {
            e.preventDefault();
            loadSubPage('distributed.html');
        });
        }

        if (
            currentFile.includes('collected.html') ||
            currentFile.includes('donor.html') ||
            currentFile.includes('distributed.html')
            ) {
        document.getElementById('btnBackToAdd')?.addEventListener('click', e => {
            e.preventDefault();
            console.log("Back button clicked"); // TEST LINE
            loadSubPage('add.html');
        });
        }

    }

    // Load add.html by default on startup
    loadSubPage('add.html');
    });
